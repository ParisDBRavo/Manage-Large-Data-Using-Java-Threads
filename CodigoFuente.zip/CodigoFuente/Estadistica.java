package proyectofinal2;

import java.text.DecimalFormat;

public final class Estadistica {

    private static final String MASCARA = "###,###";
    private static final DecimalFormat formato = new DecimalFormat(MASCARA);

    public static int[] dividir(int dividendo, int divisor) {

        int cociente = 0, residuo = dividendo;

        while (residuo >= divisor) {
            residuo -= divisor;
            cociente++;
        }
        int resultado[] = {cociente, residuo};
        return resultado;
    }

    public static String imprimirValor(int n) {
        return formato.format(n);
    }

}
