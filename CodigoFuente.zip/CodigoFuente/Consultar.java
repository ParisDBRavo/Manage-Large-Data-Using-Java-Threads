package proyectofinal2;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

public class Consultar implements Runnable {

    private static final String PCIC_HOME_TEMPORAL = "C://Users/Caronte/Documents/PCIC/calculoTemporal";
    private final int numeroArchivo;
    private final String[] nombreSegmentado;
    private static final ArrayList<String> resultados = new ArrayList<>();
    private BufferedReader f2;

    public Consultar(CSV archivoCSV,int n) {
        numeroArchivo = n;
        nombreSegmentado = archivoCSV.getNombre().split("\\.");
    }

    @Override
    public void run() {
        filtrarDatos();
    }

    private void filtrarDatos() {
        String lineaActual, registroResultado;
        String[] campos;
        int temporal = 0, indiceRegistro = 0;
        
        
        String nombreArchivo1 = nombreSegmentado[0]+"(" + numeroArchivo + ")."+nombreSegmentado[1];
        
        try {
            f2 = new BufferedReader(new FileReader(new File(PCIC_HOME_TEMPORAL, nombreArchivo1)));

            /* Lee el contenido del archivo  y busca coincidencias con el criterio establecido */
            while ((lineaActual = f2.readLine()) != null) {
                indiceRegistro++;
                campos = lineaActual.split(",");
                try {
                    temporal = Integer.parseInt(campos[2]);  //  Este es el campo de busqueda en este ejemplo
                } catch (NumberFormatException e) {
                    RegistroLogs.agregarLog(indiceRegistro, campos[2], e.getMessage());
                }
                /**
                * REEMPLACEN ESTA CONDICIONDEL IF, con la forma de como esten pasando la condicion a buscar, es decir el Filtro *
                */                
                if (temporal >= 14 && temporal <= 18) { //Criterio de Busqueda:==>  Aqui se reemplaza por algo....
                    registroResultado = "[" + indiceRegistro + "]\t" + campos[0] + "," + campos[1] + "," + campos[2];
                    
                    // descomenten la ssig lineas si quieren ver la salida parcial de cada hilo
                    //System.out.print("[" + indiceRegistro + "]\t");
                    //System.out.println(campos[0] + "," + campos[1] + "," + campos[2]);
                    agregarResultado(registroResultado);                    
                }
            }            
        } catch (IOException e) {
            System.out.println(e);
        } finally {
            try {
                f2.close();
            } catch (IOException e) { }
        }       
    }// finaliza  filtrar()

    private static synchronized void agregarResultado(String r) {
        resultados.add(r);  // Este es el secreto del universo... jajajaja.. todo simple
    }

    public static void imprimirCoincidencias() {
        System.out.println("\nCoincidencias:\t" + resultados.size());
    }
}
