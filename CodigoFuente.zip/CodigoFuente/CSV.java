package proyectofinal2;

import java.io.File;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;

public class CSV {

    /**
     * Variables de Clase
     *
     * Modulo de variables globales tipo constantes
     */
    private static final String PCIC_HOME = "C://Users/Caronte/Documents/PCIC/";

    private static final char SEPARADOR_DEFAULT = ',';

    /**
     * Variables de Instancia *
     */
    private final File archivoCSV;

    private String nombre;
    String[] nombreSegmentado;// = archivoCSV.getNombre().split("\\.");
    private int numeroRegistros;
    private int numeroColumnas;
    private final Map<Integer, String> columnas;
    private char separadorCampo;
    private boolean lectura;
    private boolean escritura;
    private Date ultimaFecha;

    public CSV(String nombre) {
        archivoCSV = new File(PCIC_HOME, nombre);
        separadorCampo = SEPARADOR_DEFAULT;
    }

    public CSV(String nombre, char separadorCampo) {
        this(nombre);
        this.separadorCampo = separadorCampo;
        this.setAtributos();
    }

    public File getArchivoCSV() {
        return archivoCSV;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public char getSeparadorCampo() {
        return separadorCampo;
    }

    public void setNumeroRegistros(int numeroRegistros) {
        this.numeroRegistros = numeroRegistros;
    }

    public int getNumeroRegistros() {
        return numeroRegistros;
    }

    public void setNumeroColumnas(int numeroColumnas) {
        this.numeroColumnas = numeroColumnas;
    }

    public int getNumeroColumnas() {
        return numeroColumnas;
    }

    private void setAtributos() {
        nombre = archivoCSV.getName();
        lectura = archivoCSV.canRead();
        escritura = archivoCSV.canWrite();
    }

    public void imprimirAtributos() {
        System.out.println("###############################");
        System.out.println("# Propiedades del archivo CSV #");
        System.out.println("#-----------------------------#");
        System.out.println("\t Archivo origen: \t\t " + nombre);
        System.out.println("\t Separador de campo: \t\t " + separadorCampo);        
        System.out.println("\t Total de registros: \t\t " + Estadistica.imprimirValor(numeroRegistros));
        System.out.println("\t Total de columnas: \t\t " + numeroColumnas);
    }

    public void setCabecera(String[] arregloCampos) {
        int indice = 0;
        for (String campoActual : arregloCampos) {
            ++indice;
            this.columnas.put(indice, campoActual);
        }
    }

    public void getCabecera() {
        // Imprimie la cabecera del archivo CSV             
        System.out.println("#---------- Cabecera del archivo CSV ----------#");
        for (int indice : columnas.keySet()) {
            System.out.println("\t[" + indice + "] " + columnas.get(indice) + ", "); 
        }
        System.out.println("#----------Fin de la cabecera ---------------#\n");
    }

    {
        this.columnas = new HashMap<>();
    }

}
