package proyectofinal2;
import java.util.Scanner;


import java.util.concurrent.*;

public class Main {
    
    private static Scanner entrada;
    
    public static void main(String[] args) {
        int i, tareasPendientes, cantidadBuscadores;
        ParticionarTarea p;
        String archivo ;//"casosDengue.csv"
        
        entrada = new Scanner(System.in);
        System.out.println(" Ingrese el nombre del archivo: ");
        archivo = entrada.nextLine();
        System.out.println(" Archivo ingresado: " + archivo);
        
       
        if (ValidarArchivo.validar(archivo)) {           
            CSV f = new CSV(archivo, ',');
            
            p = new ParticionarTarea(f);

            tareasPendientes = p.getArchivosTemporales();

            //ExecutorService buscadores = Executors.newFixedThreadPool(tareasPendientes);
            ExecutorService buscadores = Executors.newCachedThreadPool();
            // Activamos el pool de hilos enviandoles tareas
            for (i = 1; i <= tareasPendientes; i++) {
                buscadores.execute(new Consultar(f,i));
            }
            cantidadBuscadores = Thread.activeCount() - 1;

            // Se debe detener el pool
            buscadores.shutdown();
            while (!buscadores.isTerminated()) {
            }// Trampa de espera
            f.imprimirAtributos();
            System.out.println("\t Archivos temporales: \t\t " + Estadistica.imprimirValor(p.getArchivosTemporales()));
            System.out.println("\t Resgistros x archivo: \t\t " + Estadistica.imprimirValor(p.getPaginacion()));
            //f.getCabecera();
            System.out.println("#################################################################");
            
            System.out.println("# Hilos (Buscadores trabajando): \t" + cantidadBuscadores);

            Consultar.imprimirCoincidencias();
            RegistroLogs.obtenerLogsExclusionConsulta();
        } else {
            RegistroLogs.obtenerLogsValidarArchivo();
        }
    }
}
