package proyectofinal2;

import java.io.File;

public class ValidarArchivo  {
    
    //Esto no es lo mejor, pero aqui esta el ejemplo, cambien esta parte de Como le hago llegar al programa el valor de 
    // PCIC_HOME y donde deberia ser el mejor lugar para almacenar esta variable, ya que se emplea en otros lados
    private static final String PCIC_HOME = "C://Users/Caronte/Documents/PCIC/";
   
    
    
    private ValidarArchivo(){   }
   
    public static boolean validar(String nombre) {
        File f = new File(PCIC_HOME, nombre);
       
        boolean aprobado = false;
        if (f.exists()) {
            if (f.isFile()) {
                if (f.canRead()) {
                    aprobado = true;
                } else {
                    RegistroLogs.agregarLogValidarCSV("el archivo no tiene permisos de lectura"); 
                }
            } else {
                RegistroLogs.agregarLogValidarCSV("el archivo es de tipo directorio"); 
            }
        } else {
            RegistroLogs.agregarLogValidarCSV("el archivo no existe"); 
        }
        return aprobado;
    }
}
