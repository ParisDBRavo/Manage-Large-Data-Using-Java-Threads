package proyectofinal2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public final class ParticionarTarea {

    private static final String PCIC_HOME_TEMPORAL = "C://Users/Caronte/Documents/PCIC/calculoTemporal";
    private static final int PAGINACION = 500;
    private BufferedReader archivoOrigen;
    private int archivosTemporales;
    private final String[] nombreSegmentado;
    

    public ParticionarTarea(CSV archivoCSV) {
        nombreSegmentado = archivoCSV.getNombre().split("\\.");

        try {
            this.archivoOrigen = new BufferedReader(new FileReader(archivoCSV.getArchivoCSV()));

            this.calcularGranularidad(archivoCSV);
            this.particionar(archivoCSV);
        } catch (IOException e) {
        } finally {
            try {
                this.archivoOrigen.close();
            } catch (IOException e) {
            }
        }
    }

    private void calcularGranularidad(CSV archivoCSV) {
        /*
        1.- Calcular la dimension del CSV
            Numero de registros
            Numero de columnas
        2.- Invocar al metodo Estadistica.dividir() para obtener el Numero de archivos que deberan crearse   
         */
        int numeroLineas = 0;
        int[] cocienteResiduo;
        String lineaActual;
        String columnas[] = {};
        try {
            while ((lineaActual = archivoOrigen.readLine()) != null) {
                if (numeroLineas == 0) {
                    // Leemos SOLAMENTE la Primera VEZ, el primer registro, que equivale a la CABECERA del archivoCSV
                    columnas = lineaActual.split("" + archivoCSV.getSeparadorCampo() + "");
                }
                numeroLineas++;
            }           
        } catch (IOException e) {
            e.getStackTrace();
        }finally {
            try {
                archivoOrigen.close();
            } catch (IOException e) {  }
        }
        archivoCSV.setCabecera(columnas);
        archivoCSV.setNumeroColumnas(columnas.length);
        archivoCSV.setNumeroRegistros(numeroLineas);

        cocienteResiduo = Estadistica.dividir(numeroLineas, PAGINACION);
        // Comprobamos que el residuo sea mayor que cero, 
        // esto con el fin de no crear un archivo con cero registros
        if (cocienteResiduo[1] > 0) {           
            setArchivosTemporales(cocienteResiduo[0] + 1);
        } else {            
            setArchivosTemporales(cocienteResiduo[0]);
        }
    }

    public void particionar(CSV archivoCSV) {
        /*
            Variables Locales requeridas para calculos temporales
         */
        int i, cursorActual = 1, NumeroArchivo = 0;
        String lineaActual;
        String[] archivosSplit;
        File directorioTemporal; 
        
        // Arreglo de objetos BufferedWriter, para cada archivo particionado
        BufferedWriter[] archivoDestinoTemporalB;
        
        archivosSplit = new String[archivosTemporales];
        archivoDestinoTemporalB = new BufferedWriter[archivosTemporales];

        directorioTemporal = new File(PCIC_HOME_TEMPORAL);

        try {
            //Creamos el directorio temporal para almacenar los archivos particionados
            directorioTemporal.mkdirs();
            
            //Como el recurso   "archivoOrigen" se cerro en el metodo anterior, debemos refrescarlo nuevamente            
            archivoOrigen = new BufferedReader(new FileReader(archivoCSV.getArchivoCSV()));
            
            for (i = 0; i < archivosTemporales; i++) {
                //Definimos el nombre de cada particion de archivo
                archivosSplit[i] = nombreSegmentado[0] + "(" + (i + 1) + ")." + nombreSegmentado[1];
                archivoDestinoTemporalB[i] = new BufferedWriter(new FileWriter(new File(PCIC_HOME_TEMPORAL, archivosSplit[i])));
            }
            while ((lineaActual = archivoOrigen.readLine()) != null) {
                if (cursorActual != 1) {
                    archivoDestinoTemporalB[NumeroArchivo].write(lineaActual + "\n");
                    if ((cursorActual % PAGINACION) == 0) {
                        NumeroArchivo++;
                    }
                }
                cursorActual++;
            }
        } catch (IOException e) { } finally {
            try {
                archivoOrigen.close();
                for (i = 0; i < archivosTemporales; i++) {
                    archivoDestinoTemporalB[i].close();
                }
            } catch (IOException e) { }
        }
    }

    public void setArchivosTemporales(int archivosTemporales) {
        this.archivosTemporales = archivosTemporales;
    }

    public int getArchivosTemporales() {
        return archivosTemporales;
    }

    public int getPaginacion() {
        return PAGINACION;
    }

}
