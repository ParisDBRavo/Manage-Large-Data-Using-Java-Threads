package proyectofinal2;

import java.util.ArrayList;

public class RegistroLogs {

    public static ArrayList<String> logsExclusionConsulta = new ArrayList<>();
    public static ArrayList<String> logsValidarArchivo = new ArrayList<>();

    
    
    
    
    public static synchronized void agregarLog(int indiceRegistro, String contenidoExcluido, String mensajeError) {
        logsExclusionConsulta.add("[" + indiceRegistro + "] => " + contenidoExcluido + " (" + mensajeError + ")");
    }

    public static void obtenerLogsExclusionConsulta() {
        if (logsExclusionConsulta.size() > 0) {
            System.out.println("\n Registros excluidos en la busqueda: \t");
            for (String s : logsExclusionConsulta) {
                System.out.println(s);
            }
        }
    }
    
    public static void obtenerLogsValidarArchivo() {
        if (logsValidarArchivo.size() > 0) {
            System.out.println("\n# Error de validacion: \n\t");
            for (String s : logsValidarArchivo) {
                System.out.println("# ==>\t" + s.toUpperCase());
            }
        }
    }
    
    public static void agregarLogValidarCSV(String motivoExclusion) {
        logsValidarArchivo.add( motivoExclusion );
    }

}
